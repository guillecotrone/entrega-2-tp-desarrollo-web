document.getElementById('menuToggle').addEventListener('click', function () {
    const links = document.getElementById('links');
    links.classList.toggle('show');
    $('#main').toggleClass('blur');
});